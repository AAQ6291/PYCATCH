#!/usr/bin/env python
#coding=utf-8

for x in range(10):
   i=x
   print (i)
