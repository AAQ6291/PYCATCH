#!/usr/bin/env python
#coding=utf-8

days=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]

for i in days:
   print("Today's", i)

